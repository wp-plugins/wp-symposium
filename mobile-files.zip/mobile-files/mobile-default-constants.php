<?php
if ( !defined('WPS_DIR') ) 					define('WPS_DIR', 'wp-symposium');
if ( !defined('WPS_PLUGIN_DIR') ) 			define('WPS_PLUGIN_DIR', WP_PLUGIN_DIR.'/'.WPS_DIR);
?>
