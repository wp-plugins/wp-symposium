<?php
echo '</div>';
echo '<div id="footer">';
	echo '<input type="submit" onclick="location.href=\'..\/\'" class="submit tiny black floatright" value="'.__('Full site', WPS_TEXT_DOMAIN).'" />';
echo '</div>';
?>
