<?php
echo '<div id="buttons_div" style="color:white; padding:10px;">'.get_bloginfo('name').'</div>';
echo '<div class="line">';

?>

